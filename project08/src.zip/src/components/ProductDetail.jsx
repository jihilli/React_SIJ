import React from 'react'

const ProductDetail = () => {
  return (
    <div>ProductDetail</div>
  )
}

export default ProductDetail