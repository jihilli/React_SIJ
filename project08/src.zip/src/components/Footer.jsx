import React from 'react'

const Footer = () => {
  return (
    <div className='footer-container'>
        Copyright © 2023 Backpackr All right reserved.
    </div>
  )
}

export default Footer